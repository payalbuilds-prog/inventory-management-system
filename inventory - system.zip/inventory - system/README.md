# Assignment 3: Inventory and Data Management System

**Course:** Web Dev III | **Unit:** 3 | **CO:** CO3 | **Marks:** 2.5

RESTful backend to manage a store/warehouse product catalogue using **Node.js, Express.js, MongoDB, Mongoose and dotenv**.

## Folder structure
```
inventory-system/
├── server.js                      # app entry point
├── seed.js                        # inserts 12 sample products
├── .env                           # PORT, MONGO_URI (not committed)
├── config/db.js                   # MongoDB connection
├── models/Product.js              # Mongoose schema + validation + stockValue virtual
├── controllers/productController.js
├── routes/productRoutes.js
├── middleware/                    # errorHandler, validateObjectId, validateStockChange
└── utils/                         # AppError, asyncHandler
```

## Setup
```bash
npm install
npm run seed     # optional: sample data
npm start        # http://localhost:5000
```
MongoDB must be running locally (or put an Atlas URI in `.env`).

## Product schema
| Field | Rules |
|---|---|
| name | required, 2-100 chars |
| sku | required, unique, uppercase, format `STNY-PN-713` |
| category | required, one of Electronics, Apparel, Furniture, Stationery, Books, Grocery, Other |
| price | required, >= 0 |
| quantity | required, whole number >= 0 |
| reorderLevel | whole number >= 0, default 10 |
| supplier | optional string |
| stockValue | virtual = price x quantity |
| createdAt / updatedAt | automatic timestamps |

## API endpoints
| Method | URL | Purpose |
|---|---|---|
| POST | /api/products | Create product (201) |
| GET | /api/products | List with filter, sort, pagination |
| GET | /api/products/:id | Single product |
| PUT | /api/products/:id | Update product details |
| PATCH | /api/products/:id/stock | Stock adjustment: `{ "change": 10 }` restock, `{ "change": -3 }` sale |
| DELETE | /api/products/:id | Delete product |
| GET | /api/products/low-stock | Products where quantity <= reorderLevel |
| GET | /api/products/summary | Category-wise summary (aggregation) |

### Query parameters for GET /api/products
| Param | Example | Meaning |
|---|---|---|
| category | `?category=Electronics` | exact category (case-insensitive) |
| search | `?search=pen` | name contains text |
| supplier | `?supplier=ikea` | supplier contains text |
| minPrice / maxPrice | `?minPrice=500&maxPrice=3000` | price range |
| inStock | `?inStock=true` | quantity > 0 (`false` = out of stock) |
| lowStock | `?lowStock=true` | quantity <= reorderLevel |
| sort | `?sort=-price,name` | `-` means descending |
| page, limit | `?page=2&limit=5` | pagination (default limit 10, max 100) |

Example: `GET /api/products?category=Electronics&sort=-price&page=1&limit=5`

## Error handling
All errors go through one central middleware and return `{ "success": false, "message": "...", "errors": [...] }`.

| Case | Status |
|---|---|
| Schema validation failed | 400 |
| Invalid ObjectId / bad value type | 400 |
| Malformed JSON body | 400 |
| Sale larger than available stock | 400 |
| Product not found / unknown route | 404 |
| Duplicate SKU | 409 |

## Key design points
- **Safe stock updates:** `PATCH /:id/stock` uses an atomic `$inc` with a `quantity >= -change` condition, so stock can never go negative even with simultaneous requests.
- **Aggregation:** `/summary` uses `$group` (count, total quantity, total stock value, average price per category), `$project` (rounding) and `$sort`.
- **Route order:** `/low-stock` and `/summary` are declared before `/:id`.
- **Secrets:** connection string lives in `.env`, loaded with dotenv.
