const Product = require('../models/Product');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

// ---------- helpers ----------

// Builds a MongoDB filter object from the query string
// Supported: category, supplier, search, minPrice, maxPrice, inStock, lowStock
const buildFilter = (query) => {
  const filter = {};

  if (query.category) filter.category = new RegExp(`^${escapeRegex(query.category)}$`, 'i');
  if (query.supplier) filter.supplier = new RegExp(escapeRegex(query.supplier), 'i');
  if (query.search) filter.name = new RegExp(escapeRegex(query.search), 'i');

  if (query.minPrice || query.maxPrice) {
    filter.price = {};
    if (query.minPrice) filter.price.$gte = Number(query.minPrice);
    if (query.maxPrice) filter.price.$lte = Number(query.maxPrice);
  }

  if (query.inStock === 'true') filter.quantity = { $gt: 0 };
  if (query.inStock === 'false') filter.quantity = 0;

  if (query.lowStock === 'true') filter.$expr = { $lte: ['$quantity', '$reorderLevel'] };

  return filter;
};

const escapeRegex = (text) => String(text).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// sort=price,-quantity  ->  { price: 1, quantity: -1 }
const ALLOWED_SORT_FIELDS = ['name', 'sku', 'category', 'price', 'quantity', 'reorderLevel', 'createdAt', 'updatedAt'];

const buildSort = (sortQuery) => {
  if (!sortQuery) return { createdAt: -1 };
  const sort = {};
  sortQuery.split(',').forEach((raw) => {
    const field = raw.trim().replace(/^-/, '');
    if (!ALLOWED_SORT_FIELDS.includes(field)) {
      throw new AppError(`Cannot sort by "${field}". Allowed: ${ALLOWED_SORT_FIELDS.join(', ')}`, 400);
    }
    sort[field] = raw.trim().startsWith('-') ? -1 : 1;
  });
  return sort;
};

// ---------- controllers ----------

// POST /api/products
exports.createProduct = asyncHandler(async (req, res) => {
  const { name, sku, category, price, quantity, reorderLevel, supplier } = req.body;
  const product = await Product.create({ name, sku, category, price, quantity, reorderLevel, supplier });
  res.status(201).json(product);
});

// GET /api/products?category=&search=&minPrice=&maxPrice=&inStock=&lowStock=&sort=&page=&limit=
exports.getProducts = asyncHandler(async (req, res) => {
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 100);
  const skip = (page - 1) * limit;

  const filter = buildFilter(req.query);
  const sort = buildSort(req.query.sort);

  const [total, products] = await Promise.all([
    Product.countDocuments(filter),
    Product.find(filter).sort(sort).skip(skip).limit(limit),
  ]);

  res.status(200).json({
    total,
    page,
    totalPages: Math.ceil(total / limit),
    count: products.length,
    products,
  });
});

// GET /api/products/:id
exports.getProductById = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (!product) throw new AppError('Product not found', 404);
  res.status(200).json(product);
});

// PUT /api/products/:id   (update product details)
exports.updateProduct = asyncHandler(async (req, res) => {
  const allowed = ['name', 'sku', 'category', 'price', 'quantity', 'reorderLevel', 'supplier'];
  const updates = {};
  allowed.forEach((key) => {
    if (req.body[key] !== undefined) updates[key] = req.body[key];
  });

  if (Object.keys(updates).length === 0) {
    throw new AppError('No valid fields provided to update', 400);
  }

  const product = await Product.findByIdAndUpdate(req.params.id, updates, {
    new: true,
    runValidators: true,
  });
  if (!product) throw new AppError('Product not found', 404);
  res.status(200).json(product);
});

// PATCH /api/products/:id/stock   body: { "change": 10 }  (restock)  or { "change": -3 } (sale)
exports.adjustStock = asyncHandler(async (req, res) => {
  const { change } = req.body;

  // Atomic update: the filter makes sure stock can never go below zero,
  // and $inc avoids race conditions between two simultaneous requests.
  const filter = { _id: req.params.id };
  if (change < 0) filter.quantity = { $gte: -change };

  const product = await Product.findOneAndUpdate(
    filter,
    { $inc: { quantity: change } },
    { new: true, runValidators: true }
  );

  if (!product) {
    const exists = await Product.exists({ _id: req.params.id });
    if (!exists) throw new AppError('Product not found', 404);
    throw new AppError('Insufficient stock for this sale', 400);
  }

  res.status(200).json({ message: 'Stock updated', product });
});

// DELETE /api/products/:id
exports.deleteProduct = asyncHandler(async (req, res) => {
  const product = await Product.findByIdAndDelete(req.params.id);
  if (!product) throw new AppError('Product not found', 404);
  res.status(200).json({ message: 'Product deleted', id: product._id });
});

// GET /api/products/low-stock   (quantity <= reorderLevel)
exports.getLowStock = asyncHandler(async (req, res) => {
  const lowStockItems = await Product.find({ $expr: { $lte: ['$quantity', '$reorderLevel'] } }).sort({
    quantity: 1,
  });
  res.status(200).json({ count: lowStockItems.length, lowStockItems });
});

// GET /api/products/summary   (aggregation: category-wise inventory summary)
exports.getCategorySummary = asyncHandler(async (req, res) => {
  const summary = await Product.aggregate([
    {
      $group: {
        _id: '$category',
        totalItems: { $sum: 1 },
        totalQuantity: { $sum: '$quantity' },
        totalStockValue: { $sum: { $multiply: ['$price', '$quantity'] } },
        avgPrice: { $avg: '$price' },
      },
    },
    {
      $project: {
        totalItems: 1,
        totalQuantity: 1,
        totalStockValue: 1,
        avgPrice: { $round: ['$avgPrice', 2] },
      },
    },
    { $sort: { totalStockValue: -1 } },
  ]);

  res.status(200).json({ categories: summary.length, summary });
});
