const AppError = require('../utils/AppError');

// Validates body of PATCH /api/products/:id/stock -> { "change": 10 } or { "change": -3 }
module.exports = (req, res, next) => {
  const { change } = req.body || {};

  if (change === undefined || change === null) {
    return next(new AppError('"change" is required (positive = restock, negative = sale)', 400));
  }
  if (typeof change !== 'number' || !Number.isInteger(change)) {
    return next(new AppError('"change" must be a whole number', 400));
  }
  if (change === 0) {
    return next(new AppError('"change" cannot be 0', 400));
  }
  next();
};
