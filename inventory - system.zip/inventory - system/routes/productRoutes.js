const express = require('express');
const controller = require('../controllers/productController');
const validateObjectId = require('../middleware/validateObjectId');
const validateStockChange = require('../middleware/validateStockChange');

const router = express.Router();

// NOTE: fixed paths (/low-stock, /summary) must be declared BEFORE '/:id',
// otherwise Express would treat "low-stock" as an id.
router.get('/low-stock', controller.getLowStock);
router.get('/summary', controller.getCategorySummary);

router.route('/').get(controller.getProducts).post(controller.createProduct);

router
  .route('/:id')
  .get(validateObjectId, controller.getProductById)
  .put(validateObjectId, controller.updateProduct)
  .delete(validateObjectId, controller.deleteProduct);

router.patch('/:id/stock', validateObjectId, validateStockChange, controller.adjustStock);

module.exports = router;
