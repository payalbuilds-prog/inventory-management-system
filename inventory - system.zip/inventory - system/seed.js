// Run with: npm run seed
// Clears the products collection and inserts 12 sample products across 5 categories.
require('dotenv').config();
const mongoose = require('mongoose');
const Product = require('./models/Product');

const products = [
  { name: 'Wireless Mouse', sku: 'ELEC-MS-101', category: 'Electronics', price: 699, quantity: 40, reorderLevel: 10, supplier: 'Logitech India' },
  { name: 'Mechanical Keyboard', sku: 'ELEC-KB-102', category: 'Electronics', price: 2499, quantity: 8, reorderLevel: 10, supplier: 'Redragon' },
  { name: 'Bluetooth Headphones', sku: 'ELEC-HP-103', category: 'Electronics', price: 2999, quantity: 25, reorderLevel: 8, supplier: 'boAt' },
  { name: 'Power Bank 20000mAh', sku: 'ELEC-PB-104', category: 'Electronics', price: 1499, quantity: 6, reorderLevel: 10, supplier: 'Mi India' },

  { name: 'Cotton T-Shirt', sku: 'APRL-TS-201', category: 'Apparel', price: 799, quantity: 67, reorderLevel: 15, supplier: 'Allen Solly' },
  { name: 'Denim Jacket', sku: 'APRL-JK-202', category: 'Apparel', price: 1999, quantity: 11, reorderLevel: 12, supplier: 'Levis India' },

  { name: 'Study Table', sku: 'FURN-TB-812', category: 'Furniture', price: 3999, quantity: 2, reorderLevel: 4, supplier: 'IKEA India' },
  { name: 'Office Chair', sku: 'FURN-CH-813', category: 'Furniture', price: 5499, quantity: 14, reorderLevel: 5, supplier: 'Godrej Interio' },

  { name: 'A4 Notebook Pack of 5', sku: 'STNY-NB-701', category: 'Stationery', price: 250, quantity: 120, reorderLevel: 30, supplier: 'Classmate' },
  { name: 'Highlighter Set of 6', sku: 'STNY-HL-702', category: 'Stationery', price: 180, quantity: 55, reorderLevel: 20, supplier: 'Camlin' },

  { name: 'Node.js Design Patterns', sku: 'BOOK-ND-901', category: 'Books', price: 1299, quantity: 18, reorderLevel: 5, supplier: 'Packt' },
  { name: 'MongoDB: The Definitive Guide', sku: 'BOOK-MG-902', category: 'Books', price: 999, quantity: 22, reorderLevel: 5, supplier: 'OReilly' },
];

(async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    await Product.deleteMany({});
    await Product.syncIndexes();
    const created = await Product.insertMany(products);
    console.log(`Seeded ${created.length} products`);
  } catch (err) {
    console.error('Seeding failed:', err.message);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
})();
